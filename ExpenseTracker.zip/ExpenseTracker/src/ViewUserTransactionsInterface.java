import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;
import java.util.*;
import java.util.List;
import java.util.ArrayList;

public class ViewUserTransactionsInterface extends JFrame {
    private DatabaseConnector dbConnector;

    public ViewUserTransactionsInterface() {
        dbConnector = new DatabaseConnector();
        setTitle("View User Transactions");
        setSize(800, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        // Label for selecting User ID
        JLabel userIdLabel = new JLabel("Select User:");
        userIdLabel.setBounds(50, 50, 150, 25);
        add(userIdLabel);

        // ComboBox for selecting user
        JComboBox<String> userComboBox = new JComboBox<>();
        userComboBox.setBounds(200, 50, 200, 25);
        add(userComboBox);

        // Date Range Filters
        JLabel startDateLabel = new JLabel("Start Date:");
        startDateLabel.setBounds(50, 100, 100, 25);
        add(startDateLabel);

        JSpinner startDateSpinner = new JSpinner(new SpinnerDateModel());
        startDateSpinner.setBounds(200, 100, 200, 25);
        JSpinner.DateEditor startDateEditor = new JSpinner.DateEditor(startDateSpinner, "yyyy-MM-dd");
        startDateSpinner.setEditor(startDateEditor);
        add(startDateSpinner);

        JLabel endDateLabel = new JLabel("End Date:");
        endDateLabel.setBounds(50, 150, 100, 25);
        add(endDateLabel);

        JSpinner endDateSpinner = new JSpinner(new SpinnerDateModel());
        endDateSpinner.setBounds(200, 150, 200, 25);
        JSpinner.DateEditor endDateEditor = new JSpinner.DateEditor(endDateSpinner, "yyyy-MM-dd");
        endDateSpinner.setEditor(endDateEditor);
        add(endDateSpinner);

        // Filter by Transaction Type (Expense Category)
        JLabel categoryLabel = new JLabel("Category Filter:");
        categoryLabel.setBounds(50, 200, 150, 25);
        add(categoryLabel);

        JComboBox<String> categoryDropdown = new JComboBox<>();
        categoryDropdown.addItem("All Categories");
        categoryDropdown.setBounds(200, 200, 200, 25);
        add(categoryDropdown);

        // Button to load user transactions
        JButton viewTransactionsButton = new JButton("View Transactions");
        viewTransactionsButton.setBounds(50, 250, 200, 30);
        add(viewTransactionsButton);

        // Message label for showing "No transactions available"
        JLabel messageLabel = new JLabel();
        messageLabel.setBounds(50, 300, 300, 25);
        add(messageLabel);

        // JTable for displaying the transactions
        JTable transactionsTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(transactionsTable);
        scrollPane.setBounds(50, 350, 700, 150);
        add(scrollPane);

        // Populate User ComboBox with users
        try {
            dbConnector.connect();
            ResultSet rs = dbConnector.getUsers();
            while (rs.next()) {
                String userId = rs.getString("user_id");
                String fullName = rs.getString("first_name") + " " + rs.getString("last_name");
                userComboBox.addItem(fullName + " (" + userId + ")");
            }
            dbConnector.disconnect();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading users: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Populate Category Dropdown
        try {
            dbConnector.connect();
            ResultSet rs = dbConnector.getCategories();
            while (rs.next()) {
                categoryDropdown.addItem(rs.getString("name"));
            }
            dbConnector.disconnect();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading categories: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Action when the "View Transactions" button is clicked
        viewTransactionsButton.addActionListener(e -> {
    String selectedUser = (String) userComboBox.getSelectedItem();
    if (selectedUser == null || selectedUser.isEmpty()) {
        messageLabel.setText("Please select a valid user.");
        return;
    }

    // Extract the user ID (e.g., "John Doe (1)" => "1")
    String userIdStr = selectedUser.substring(selectedUser.lastIndexOf("(") + 1, selectedUser.lastIndexOf(")"));
    int userId = Integer.parseInt(userIdStr);

    java.util.Date startDate = (java.util.Date) startDateSpinner.getValue();
    java.util.Date endDate = (java.util.Date) endDateSpinner.getValue();
    String selectedCategory = (String) categoryDropdown.getSelectedItem();

    try {
        dbConnector.connect();

        java.sql.Date sqlStartDate = (startDate != null) ? new java.sql.Date(startDate.getTime()) : null;
        java.sql.Date sqlEndDate = (endDate != null) ? new java.sql.Date(endDate.getTime()) : null;

        ResultSet rs = dbConnector.getUserTransactions(userId, sqlStartDate, sqlEndDate, selectedCategory);

        // Create a list to hold the data
        List<Vector<Object>> data = new ArrayList<>();
        ResultSetMetaData metaData = rs.getMetaData();
        int columnCount = metaData.getColumnCount();

        while (rs.next()) {
            Vector<Object> row = new Vector<>(columnCount);
            for (int i = 1; i <= columnCount; i++) {
                row.add(rs.getObject(i));
            }
            data.add(row);
        }

        // Convert List<Vector<Object>> to Vector<Vector<Object>>
        Vector<Vector<Object>> dataVector = new Vector<>(data);

        // Check if any transactions were found
        if (dataVector.isEmpty()) {
            messageLabel.setText("No transactions available.");
            transactionsTable.setModel(new DefaultTableModel()); // Clear table
        } else {
            Vector<String> columnNames = new Vector<>(columnCount);
            for (int i = 1; i <= columnCount; i++) {
                columnNames.add(metaData.getColumnName(i));
            }

            // Update the JTable model
            SwingUtilities.invokeLater(() -> {
                transactionsTable.setModel(new DefaultTableModel(dataVector, columnNames));
            });
            messageLabel.setText(""); // Clear any previous error message
        }
        dbConnector.disconnect();
    } catch (SQLException ex) {
        messageLabel.setText("Error fetching transactions: " + ex.getMessage());
    }
});

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ViewUserTransactionsInterface().setVisible(true));
    }
}
