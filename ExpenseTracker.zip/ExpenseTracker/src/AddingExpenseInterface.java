import javax.swing.*;
import java.sql.*;
import java.util.Vector;

public class AddingExpenseInterface extends JFrame {
    private DatabaseConnector dbConnector;

    public AddingExpenseInterface() {
        dbConnector = new DatabaseConnector();
        setTitle("Add Expense");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JLabel expenseTypeLabel = new JLabel("Expense Type:");
        expenseTypeLabel.setBounds(50, 50, 100, 25);
        add(expenseTypeLabel);

        // Expense Type Dropdown
        JComboBox<String> expenseTypeDropdown = new JComboBox<>();
        expenseTypeDropdown.setBounds(150, 50, 200, 25);
        add(expenseTypeDropdown);

        JLabel amountLabel = new JLabel("Amount:");
        amountLabel.setBounds(50, 100, 100, 25);
        add(amountLabel);

        JTextField amountField = new JTextField();
        amountField.setBounds(150, 100, 200, 25);
        add(amountField);

        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setBounds(50, 150, 100, 25);
        add(dateLabel);

        JTextField dateField = new JTextField();
        dateField.setBounds(150, 150, 200, 25);
        add(dateField);

        JLabel notesLabel = new JLabel("Notes:");
        notesLabel.setBounds(50, 200, 100, 25);
        add(notesLabel);

        JTextArea notesField = new JTextArea();
        notesField.setBounds(150, 200, 200, 50);
        add(notesField);

        JButton addButton = new JButton("Add Expense");
        addButton.setBounds(150, 280, 100, 30);
        add(addButton);

        JLabel errorLabel = new JLabel();
        errorLabel.setBounds(50, 320, 300, 25);
        errorLabel.setForeground(java.awt.Color.RED);
        add(errorLabel);

        // Fetch categories from the database and populate the dropdown
        try {
            dbConnector.connect();
            ResultSet rs = dbConnector.getCategories();
            while (rs.next()) {
                expenseTypeDropdown.addItem(rs.getString("name"));
            }
            dbConnector.disconnect();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading categories: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Add Expense Button Action
        addButton.addActionListener(e -> {
            String expenseType = (String) expenseTypeDropdown.getSelectedItem();
            String amountText = amountField.getText();
            String date = dateField.getText();
            String notes = notesField.getText();

            if (amountText.isEmpty() || date.isEmpty()) {
                errorLabel.setText("Amount and Date are required fields.");
                return;
            }

            try {
                double amount = Double.parseDouble(amountText);
                dbConnector.connect();
                boolean success = dbConnector.addExpense(expenseType, amount, date, notes);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Expense Added Successfully!");
                    dispose();
                } else {
                    errorLabel.setText("Failed to add expense.");
                }
                dbConnector.disconnect();
            } catch (NumberFormatException ex) {
                errorLabel.setText("Invalid amount.");
            } catch (SQLException ex) {
                errorLabel.setText("Database error: " + ex.getMessage());
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AddingExpenseInterface().setVisible(true));
    }
}
