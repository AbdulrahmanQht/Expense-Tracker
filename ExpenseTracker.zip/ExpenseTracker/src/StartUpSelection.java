import javax.swing.*;

public class StartUpSelection extends JFrame {
    public StartUpSelection() {
        setTitle("Start-Up Selection");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(50, 50, 100, 30);
        add(loginButton);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(150, 50, 100, 30);
        add(registerButton);

        // Navigate to Login Interface
        loginButton.addActionListener(e -> {
            new LoginInterface().setVisible(true);
            dispose();  // Close the current Start-Up Selection window
        });

        // Navigate to Registration Interface
        registerButton.addActionListener(e -> {
            new RegistrationInterface().setVisible(true);
            dispose();  // Close the current Start-Up Selection window
        });
    }

    public static void main(String[] args) {
        // Make sure Start-Up Selection is shown first
        SwingUtilities.invokeLater(() -> new StartUpSelection().setVisible(true));
    }
}
