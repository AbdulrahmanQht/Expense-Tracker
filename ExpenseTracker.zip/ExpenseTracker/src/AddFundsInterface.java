import javax.swing.*;
import java.sql.*;

public class AddFundsInterface extends JFrame {
    private DatabaseConnector dbConnector;

    public AddFundsInterface() {
        dbConnector = new DatabaseConnector();
        setTitle("Add Funds");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JLabel sourceLabel = new JLabel("Source of Income:");
        sourceLabel.setBounds(50, 50, 150, 25);
        add(sourceLabel);

        String[] incomeSources = {"Salary", "Gift", "Freelance", "Other"};
        JComboBox<String> sourceDropdown = new JComboBox<>(incomeSources);
        sourceDropdown.setBounds(200, 50, 150, 25);
        add(sourceDropdown);

        JLabel amountLabel = new JLabel("Amount:");
        amountLabel.setBounds(50, 100, 100, 25);
        add(amountLabel);

        JTextField amountField = new JTextField();
        amountField.setBounds(150, 100, 200, 25);
        add(amountField);

        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setBounds(50, 150, 100, 25);
        add(dateLabel);

        JTextField dateField = new JTextField();
        dateField.setBounds(150, 150, 200, 25);
        add(dateField);

        JLabel notesLabel = new JLabel("Notes:");
        notesLabel.setBounds(50, 200, 100, 25);
        add(notesLabel);

        JTextArea notesField = new JTextArea();
        notesField.setBounds(150, 200, 200, 50);
        add(notesField);

        JButton addFundsButton = new JButton("Add Funds");
        addFundsButton.setBounds(150, 250, 100, 30);
        add(addFundsButton);

        JLabel errorLabel = new JLabel();
        errorLabel.setBounds(50, 280, 300, 25);
        errorLabel.setForeground(java.awt.Color.RED);
        add(errorLabel);

        addFundsButton.addActionListener(e -> {
            String incomeSource = (String) sourceDropdown.getSelectedItem();
            String amountText = amountField.getText();
            String date = dateField.getText();
            String notes = notesField.getText();

            if (amountText.isEmpty() || date.isEmpty()) {
                errorLabel.setText("Amount and Date are required fields.");
                return;
            }

            try {
                double amount = Double.parseDouble(amountText);
                dbConnector.connect();
                boolean success = dbConnector.addFunds(incomeSource, amount, date, notes);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Funds Added Successfully!");
                    dispose();
                } else {
                    errorLabel.setText("Failed to add funds.");
                }
                dbConnector.disconnect();
            } catch (NumberFormatException ex) {
                errorLabel.setText("Invalid amount.");
            } catch (SQLException ex) {
                errorLabel.setText("Database error: " + ex.getMessage());
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AddFundsInterface().setVisible(true));
    }
}
