import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.sql.*;
import java.util.*;

public class AnalysisExpensesInterface extends JFrame {
    private DatabaseConnector dbConnector;
    private Map<String, Double> categoryData = new HashMap<>();
    private boolean showAllExpenses = false;

    public AnalysisExpensesInterface() {
        dbConnector = new DatabaseConnector();
        setTitle("Expense Analysis");
        setSize(1000, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        // Date Range Picker Using JSpinner
        JLabel dateRangeLabel = new JLabel("Select Date Range:");
        dateRangeLabel.setBounds(50, 50, 150, 25);
        add(dateRangeLabel);

        // Start Date Spinner
        JSpinner startDateSpinner = new JSpinner(new SpinnerDateModel());
        startDateSpinner.setBounds(200, 50, 120, 25);
        JSpinner.DateEditor startDateEditor = new JSpinner.DateEditor(startDateSpinner, "yyyy-MM-dd");
        startDateSpinner.setEditor(startDateEditor);
        add(startDateSpinner);

        // End Date Spinner
        JSpinner endDateSpinner = new JSpinner(new SpinnerDateModel());
        endDateSpinner.setBounds(350, 50, 120, 25);
        JSpinner.DateEditor endDateEditor = new JSpinner.DateEditor(endDateSpinner, "yyyy-MM-dd");
        endDateSpinner.setEditor(endDateEditor);
        add(endDateSpinner);

        // Category Filter Dropdown
        JLabel categoryLabel = new JLabel("Select Category:");
        categoryLabel.setBounds(50, 100, 150, 25);
        add(categoryLabel);

        JComboBox<String> categoryDropdown = new JComboBox<>();
        categoryDropdown.addItem("All Categories"); // Allow filtering by all categories
        categoryDropdown.setBounds(200, 100, 200, 25);
        add(categoryDropdown);

        // Total Expenses Text
        JLabel totalLabel = new JLabel("Total Expenses: ");
        totalLabel.setBounds(50, 150, 150, 25);
        add(totalLabel);

        JLabel totalExpenses = new JLabel("0");
        totalExpenses.setBounds(200, 150, 150, 25);
        add(totalExpenses);

        // Transactions Table
        JTable transactionTable = new JTable(new DefaultTableModel(new Object[]{"ID", "Category", "Amount", "Date", "Notes"}, 0));
        JScrollPane scrollPane = new JScrollPane(transactionTable);
        scrollPane.setBounds(50, 200, 900, 200);
        add(scrollPane);

        // Chart Panel
        JPanel chartPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                drawCharts(g);
            }
        };
        chartPanel.setBounds(50, 450, 900, 300);
        chartPanel.setBackground(Color.WHITE);
        add(chartPanel);

        // Populate Category Dropdown
        try {
            dbConnector.connect();
            ResultSet rs = dbConnector.getCategories();
            while (rs.next()) {
                categoryDropdown.addItem(rs.getString("name"));
            }
            dbConnector.disconnect();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading categories: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Filter Button
        JButton filterButton = new JButton("Filter");
        filterButton.setBounds(500, 100, 100, 30);
        add(filterButton);

        filterButton.addActionListener(e -> {
            java.util.Date startDate = (java.util.Date) startDateSpinner.getValue();
            java.util.Date endDate = (java.util.Date) endDateSpinner.getValue();
            String selectedCategory = (String) categoryDropdown.getSelectedItem();

            if ("All Categories".equals(selectedCategory)) {
                showAllExpenses = true;
            } else {
                showAllExpenses = false;
            }

            if (!showAllExpenses && (startDate == null || endDate == null)) {
                JOptionPane.showMessageDialog(this, "Please select a valid date range.");
                return;
            }

            try {
                dbConnector.connect();

                // Convert java.util.Date to java.sql.Date
                java.sql.Date sqlStartDate = startDate != null ? new java.sql.Date(startDate.getTime()) : null;
                java.sql.Date sqlEndDate = endDate != null ? new java.sql.Date(endDate.getTime()) : null;

                // Fetch filtered data from the database
                ResultSet rs = showAllExpenses
                        ? dbConnector.getAllExpenses()
                        : dbConnector.getExpenseAnalysis(sqlStartDate, sqlEndDate, selectedCategory);

                double total = 0;
                DefaultTableModel model = (DefaultTableModel) transactionTable.getModel();
                model.setRowCount(0);  // Clear previous data

                // Clear previous chart data
                categoryData.clear();

                while (rs.next()) {
                    double amount = rs.getDouble("amount");
                    total += amount;

                    // Update chart data
                    String categoryName = rs.getString("name");
                    categoryData.put(categoryName, categoryData.getOrDefault(categoryName, 0.0) + amount);

                    // Update transaction table
                    Object[] row = {rs.getString("expense_id"), categoryName, amount, rs.getDate("date"), rs.getString("notes")};
                    model.addRow(row);
                }
                totalExpenses.setText(String.valueOf(total));
                chartPanel.repaint();  // Redraw the chart
                dbConnector.disconnect();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error filtering data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Export Button
        JButton exportButton = new JButton("Export as CSV");
        exportButton.setBounds(650, 100, 150, 30);
        add(exportButton);

        exportButton.addActionListener(e -> {
            try {
                DefaultTableModel model = (DefaultTableModel) transactionTable.getModel();
                exportTableDataToCSV(model);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error exporting data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    // Method to export table data to CSV
    private void exportTableDataToCSV(DefaultTableModel model) throws IOException {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save CSV File");
        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try (FileWriter writer = new FileWriter(fileToSave)) {
                // Write column headers
                for (int col = 0; col < model.getColumnCount(); col++) {
                    writer.write(model.getColumnName(col) + ",");
                }
                writer.write("\n");

                // Write row data
                for (int row = 0; row < model.getRowCount(); row++) {
                    for (int col = 0; col < model.getColumnCount(); col++) {
                        writer.write(model.getValueAt(row, col) + ",");
                    }
                    writer.write("\n");
                }
                JOptionPane.showMessageDialog(this, "Data exported successfully!");
            }
        }
    }

    // Draw charts (bar chart and pie chart)
    private void drawCharts(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;

        if (categoryData.isEmpty()) {
            g2d.drawString("No data available for the selected filters.", 50, 50);
            return;
        }

        // Bar Chart
        int barX = 50, barY = 50, barWidth = 80, maxHeight = 200;
        double maxAmount = Collections.max(categoryData.values());

        g2d.setColor(Color.BLUE);
        int i = 0;
        for (Map.Entry<String, Double> entry : categoryData.entrySet()) {
            int barHeight = (int) ((entry.getValue() / maxAmount) * maxHeight);
            g2d.fillRect(barX + (i * (barWidth + 20)), barY + (maxHeight - barHeight), barWidth, barHeight);
            g2d.drawString(entry.getKey(), barX + (i * (barWidth + 20)), barY + maxHeight + 15);
            g2d.drawString(String.valueOf(entry.getValue()), barX + (i * (barWidth + 20)), barY + (maxHeight - barHeight - 5)); // Amount on top
            i++;
        }

        // Pie Chart
        int pieX = 600, pieY = 50, pieWidth = 200, pieHeight = 200;
        double total = categoryData.values().stream().mapToDouble(Double::doubleValue).sum();
        int startAngle = 0;

        i = 0;
        Color[] pieColors = {Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW};
        for (Map.Entry<String, Double> entry : categoryData.entrySet()) {
            int arcAngle = (int) ((entry.getValue() / total) * 360);
            g2d.setColor(pieColors[i % pieColors.length]);
            g2d.fillArc(pieX, pieY, pieWidth, pieHeight, startAngle, arcAngle);

            // Add percentage
            String percentage = String.format("%.1f%%", (entry.getValue() / total) * 100);
            g2d.drawString(percentage, pieX + (int) (pieWidth * Math.cos(Math.toRadians(startAngle + arcAngle / 2))),
                    pieY + (int) (pieHeight * Math.sin(Math.toRadians(startAngle + arcAngle / 2))));

            startAngle += arcAngle;
            i++;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AnalysisExpensesInterface().setVisible(true));
    }
}
