import javax.swing.*;

public class SelectionInterface extends JFrame {
    public SelectionInterface() {
        setTitle("Selection Interface");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        // Welcome Message
        JLabel welcomeMessage = new JLabel("Welcome, User!");
        welcomeMessage.setBounds(150, 30, 100, 30);
        add(welcomeMessage);

        // Add Funds Button
        JButton addFundsButton = new JButton("Add Funds");
        addFundsButton.setBounds(150, 80, 100, 30);
        add(addFundsButton);

        // Add Expense Button
        JButton addExpenseButton = new JButton("Add Expense");
        addExpenseButton.setBounds(150, 120, 100, 30);
        add(addExpenseButton);

        // Account Linking Button
        JButton linkAccountButton = new JButton("Link Account");
        linkAccountButton.setBounds(150, 160, 100, 30);
        add(linkAccountButton);

        // Expense Analysis Button
        JButton expenseAnalysisButton = new JButton("Expense Analysis");
        expenseAnalysisButton.setBounds(150, 200, 130, 30);
        add(expenseAnalysisButton);

        // Action listeners for navigation
        addFundsButton.addActionListener(e -> {
            new AddFundsInterface().setVisible(true);
            dispose();  // Close the selection screen
        });

        addExpenseButton.addActionListener(e -> {
            new AddingExpenseInterface().setVisible(true);
            dispose();
        });

        linkAccountButton.addActionListener(e -> {
            new LinkBankAccountInterface().setVisible(true);
            dispose();
        });

        expenseAnalysisButton.addActionListener(e -> {
            new AnalysisExpensesInterface().setVisible(true);
            dispose();
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SelectionInterface().setVisible(true));
    }
}
