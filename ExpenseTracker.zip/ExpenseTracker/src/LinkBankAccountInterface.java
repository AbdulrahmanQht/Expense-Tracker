import javax.swing.*;
import java.sql.*;
import java.awt.Desktop;
import java.net.URI;

public class LinkBankAccountInterface extends JFrame {
    private DatabaseConnector dbConnector;

    public LinkBankAccountInterface() {
        dbConnector = new DatabaseConnector();
        setTitle("Link Bank Account");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JLabel bankLabel = new JLabel("Select Bank:");
        bankLabel.setBounds(50, 50, 100, 25);
        add(bankLabel);

        // Dropdown to select a bank
        JComboBox<String> bankDropdown = new JComboBox<>();
        bankDropdown.setBounds(150, 50, 200, 25);
        add(bankDropdown);

        // Button to link the selected bank account
        JButton linkButton = new JButton("Link Account");
        linkButton.setBounds(150, 100, 150, 30);
        add(linkButton);

        // Action listener for link button
        linkButton.addActionListener(e -> {
            String selectedBank = (String) bankDropdown.getSelectedItem();
            try {
                dbConnector.connect();
                String bankUrl = getBankUrl(selectedBank);
                if (bankUrl != null) {
                    // Redirect to the bank's official website
                    openBrowser(bankUrl);
                } else {
                    JOptionPane.showMessageDialog(this, "Error: Unable to fetch bank URL.", "Error", JOptionPane.ERROR_MESSAGE);
                }
                dbConnector.disconnect();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Populate the bank names from the database
        try {
            dbConnector.connect();
            ResultSet rs = dbConnector.getBanks();
            while (rs.next()) {
                bankDropdown.addItem(rs.getString("bank_name"));
            }
            dbConnector.disconnect();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading bank accounts: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to get the bank's URL from the database
    private String getBankUrl(String bankName) throws SQLException {
        String query = "SELECT bank_url FROM Bank WHERE bank_name = ?";
        PreparedStatement stmt = dbConnector.connection.prepareStatement(query);
        stmt.setString(1, bankName);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return rs.getString("bank_url");
        }
        return null;
    }

    // Method to open the URL in the default browser
    private void openBrowser(String url) {
        try {
            Desktop desktop = Desktop.getDesktop();
            URI uri = new URI(url);
            desktop.browse(uri);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error opening browser: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LinkBankAccountInterface().setVisible(true));
    }
}
