import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminFinancialManagementInterface extends JFrame {
    private DatabaseConnector dbConnector;
    private String userRole;

    public AdminFinancialManagementInterface(String role) {
        dbConnector = new DatabaseConnector();
        this.userRole = role;  // Assume role is passed as a parameter (admin or user)
        setTitle("Admin Financial Management");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Use GridLayout with 3 rows (1 for the label, 2 for the buttons) and 2 columns for buttons
        setLayout(new GridLayout(3, 2, 10, 10));  // 3 rows, 2 columns with 10px gap

        // Manage label for action
        JLabel manageLabel = new JLabel("Select an Action:");
        manageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(manageLabel);  // First row

        // View Reports Button
        JButton viewReportsButton = new JButton("View Reports");
        add(viewReportsButton);  // Second row, first column

        // View User Transactions Button
        JButton viewUserTransactionsButton = new JButton("View User Transactions");
        add(viewUserTransactionsButton);  // Second row, second column

        // Delete Transaction Button
        JButton deleteTransactionButton = new JButton("Delete Transaction");
        add(deleteTransactionButton);  // Third row, first column

        // Manage User Accounts Button
        JButton manageUserAccountsButton = new JButton("Manage User Accounts");
        add(manageUserAccountsButton);  // Third row, second column

        // Action listeners for buttons
        viewReportsButton.addActionListener(e -> {
            if ("admin".equals(userRole)) {
                showReports();
            } else {
                JOptionPane.showMessageDialog(this, "Access Denied. Only admins can view reports.");
            }
        });

        viewUserTransactionsButton.addActionListener(e -> {
            if ("admin".equals(userRole)) {
                viewUserTransactions();
            } else {
                JOptionPane.showMessageDialog(this, "Access Denied. Only admins can view user transactions.");
            }
        });

        deleteTransactionButton.addActionListener(e -> {
            if ("admin".equals(userRole)) {
                deleteTransaction();
            } else {
                JOptionPane.showMessageDialog(this, "Access Denied. Only admins can delete transactions.");
            }
        });

        manageUserAccountsButton.addActionListener(e -> {
            if ("admin".equals(userRole)) {
                manageUserAccounts();
            } else {
                JOptionPane.showMessageDialog(this, "Access Denied. Only admins can manage user accounts.");
            }
        });
    }

    // Redirect to the "View Reports" Interface
    private void showReports() {
        new ViewReportsInterface().setVisible(true);  // Example: Redirect to ViewReportsInterface
        this.dispose();  // Close the current interface
    }

    // Redirect to the "View User Transactions" Interface
    private void viewUserTransactions() {
        new ViewUserTransactionsInterface().setVisible(true);  // Example: Redirect to ViewUserTransactionsInterface
        this.dispose();  // Close the current interface
    }

    // Redirect to the "Delete Transaction" Interface
    private void deleteTransaction() {
        new DeleteTransactionInterface().setVisible(true);  // Example: Redirect to DeleteTransactionInterface
        this.dispose();  // Close the current interface
    }

    // Redirect to the "Manage User Accounts" Interface
    private void manageUserAccounts() {
        new ManageUserAccountsInterface().setVisible(true);  // Example: Redirect to ManageUserAccountsInterface
        this.dispose();  // Close the current interface
    }

    public static void main(String[] args) {
        // Example: Pass role to the interface constructor. In a real app, role would be determined after login.
        SwingUtilities.invokeLater(() -> new AdminFinancialManagementInterface("admin").setVisible(true));
    }
}
