import javax.swing.*;
import java.sql.*;

public class DeleteExpenseInterface extends JFrame {
    private DatabaseConnector dbConnector;

    public DeleteExpenseInterface() {
        dbConnector = new DatabaseConnector();
        setTitle("Delete Expense");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JLabel expenseLabel = new JLabel("Select Expense to Delete:");
        expenseLabel.setBounds(50, 50, 200, 25);
        add(expenseLabel);

        JComboBox<String> expenseDropdown = new JComboBox<>();
        expenseDropdown.setBounds(50, 100, 300, 25);
        add(expenseDropdown);

        JButton deleteButton = new JButton("Delete Expense");
        deleteButton.setBounds(150, 150, 150, 30);
        add(deleteButton);

        try {
            dbConnector.connect();
            ResultSet rs = dbConnector.getExpenses();  // Query to get expenses
            while (rs.next()) {
                expenseDropdown.addItem(rs.getString("expense_id"));
            }
            dbConnector.disconnect();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading expenses: " + ex.getMessage());
        }

        // Action for Delete Expense Button
        deleteButton.addActionListener(e -> {
            String selectedExpense = (String) expenseDropdown.getSelectedItem();
            if (selectedExpense != null) {
                try {
                    dbConnector.connect();
                    boolean success = dbConnector.deleteExpense(Integer.parseInt(selectedExpense));
                    if (success) {
                        JOptionPane.showMessageDialog(this, "Expense deleted successfully.");
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to delete expense.");
                    }
                    dbConnector.disconnect();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DeleteExpenseInterface().setVisible(true));
    }
}
