import java.sql.*;

public class DatabaseConnector {
    private static final String URL = "jdbc:mysql://localhost:3306/ExpenseTracker";
    private static final String USER = "root";
    private static final String PASSWORD = "1234567";
    Connection connection;

    // Establish connection to the database
    public void connect() throws SQLException {
        connection = DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // Close the connection
    public void disconnect() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

    
     public ResultSet getBanks() throws SQLException {
        String query = "SELECT bank_name FROM Bank";  // Assuming 'Bank' table has 'bank_name' column
        Statement stmt = connection.createStatement();
        return stmt.executeQuery(query);
    }
    
       public boolean sendPasswordResetToken(String email, String token) throws SQLException {
        String query = "SELECT user_id FROM User WHERE email = ?";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setString(1, email);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            // If email exists, store the password reset token
            int userId = rs.getInt("user_id");
            String updateQuery = "UPDATE User SET password_reset_token = ? WHERE user_id = ?";
            PreparedStatement updateStmt = connection.prepareStatement(updateQuery);
            updateStmt.setString(1, token);
            updateStmt.setInt(2, userId);
            updateStmt.executeUpdate();
            return true;  // Email exists and token is saved
        }
        return false;  // Email doesn't exist
    }

    // Method to verify the reset token and reset the password
    public boolean verifyTokenAndResetPassword(String token, String newPassword) throws SQLException {
        // Find user with the matching reset token
        String query = "SELECT user_id FROM User WHERE password_reset_token = ?";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setString(1, token);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            // If token is correct, reset the password
            int userId = rs.getInt("user_id");
            String updatePasswordQuery = "UPDATE User SET password = ? WHERE user_id = ?";
            PreparedStatement updatePasswordStmt = connection.prepareStatement(updatePasswordQuery);
            updatePasswordStmt.setString(1, newPassword);
            updatePasswordStmt.setInt(2, userId);
            updatePasswordStmt.executeUpdate();
            
            // Optionally, clear the token after successful password reset
            String clearTokenQuery = "UPDATE User SET password_reset_token = NULL WHERE user_id = ?";
            PreparedStatement clearTokenStmt = connection.prepareStatement(clearTokenQuery);
            clearTokenStmt.setInt(1, userId);
            clearTokenStmt.executeUpdate();
            return true;  // Password reset successfully
        }
        return false;  // Invalid token
    }
    public boolean registerUser(String firstName, String lastName, String email, String phoneNumber, String password) throws SQLException {
        String query = "INSERT INTO User (first_name, last_name, email, phone_number, password, role) VALUES (?, ?, ?, ?, ?, 'user')";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setString(1, firstName);
        stmt.setString(2, lastName);
        stmt.setString(3, email);
        stmt.setString(4, phoneNumber);
        stmt.setString(5, password); // In a production environment, you should hash the password before storing it

        // Execute the insert statement and return whether the operation was successful
        return stmt.executeUpdate() > 0;  // Returns true if at least one row is inserted
    }  
    
    
    
    // Get all users from the User table
    public ResultSet getUsers() throws SQLException {
        String query = "SELECT user_id, first_name, last_name, email, role FROM User";
        Statement stmt = connection.createStatement();
        return stmt.executeQuery(query);
    }

    // Update a user's details (name, email, and role)
    public boolean updateUser(int userId, String name, String email, String role) throws SQLException {
        String query = "UPDATE User SET first_name = ?, last_name = ?, email = ?, role = ? WHERE user_id = ?";
        PreparedStatement stmt = connection.prepareStatement(query);
        String[] names = name.split(" ");  // Assuming name is in "First Last" format
        stmt.setString(1, names[0]);  // First name
        stmt.setString(2, names[1]);  // Last name
        stmt.setString(3, email);
        stmt.setString(4, role);
        stmt.setInt(5, userId);
        
        return stmt.executeUpdate() > 0;
    }

    // Delete a user from the User table
    public boolean deleteUser(int userId) throws SQLException {
        String query = "DELETE FROM User WHERE user_id = ?";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setInt(1, userId);
        return stmt.executeUpdate() > 0;
    }

    // Method to get user transactions (for reports)
    public ResultSet getUserTransactions(int userId, java.sql.Date startDate, java.sql.Date endDate, String category) throws SQLException {
        StringBuilder query = new StringBuilder(
                "SELECT e.expense_id, u.first_name, u.last_name, c.name AS category, e.amount, e.date " +
                "FROM Expense e " +
                "JOIN User u ON e.user_id = u.user_id " +
                "JOIN Category c ON e.category_id = c.category_id WHERE e.user_id = ?");

        // Add filters for date range and category
        if (startDate != null) {
            query.append(" AND e.date >= ?");
        }
        if (endDate != null) {
            query.append(" AND e.date <= ?");
        }
        if (category != null && !category.equals("All Categories")) {
            query.append(" AND c.name = ?");
        }

        PreparedStatement stmt = connection.prepareStatement(query.toString());
        stmt.setInt(1, userId);

        int paramIndex = 2;
        if (startDate != null) {
            stmt.setDate(paramIndex++, startDate);
        }
        if (endDate != null) {
            stmt.setDate(paramIndex++, endDate);
        }
        if (category != null && !category.equals("All Categories")) {
            stmt.setString(paramIndex++, category);
        }

        return stmt.executeQuery();
    }

    // Method to get categories
    public ResultSet getCategories() throws SQLException {
        String query = "SELECT name FROM Category";
        Statement stmt = connection.createStatement();
        return stmt.executeQuery(query);
    }

    // Method to get report data (expenses within a date range and category filter)
    public ResultSet getReportData(java.sql.Date startDate, java.sql.Date endDate, String category) throws SQLException {
        StringBuilder query = new StringBuilder(
        "SELECT e.expense_id, u.first_name, u.last_name, c.name AS category, e.amount, e.date " +
        "FROM Expense e " +
        "JOIN User u ON e.user_id = u.user_id " +
        "JOIN Category c ON e.category_id = c.category_id WHERE e.date BETWEEN ? AND ?");

        // If a specific category is selected, add a condition to filter by category
        if (category != null && !category.equals("All Categories")) {
            query.append(" AND c.name = ?");
        }

        PreparedStatement stmt = connection.prepareStatement(query.toString());
        stmt.setDate(1, startDate);
        stmt.setDate(2, endDate);

        // Set the category filter if a specific category is selected
        if (category != null && !category.equals("All Categories")) {
            stmt.setString(3, category);
        }

        return stmt.executeQuery();
    }

    // Add an expense to the Expense table
    public boolean addExpense(String expenseType, double amount, String date, String notes) throws SQLException {
        // First, we need to get the category_id for the selected expense type
        String categoryQuery = "SELECT category_id FROM Category WHERE name = ?";
        PreparedStatement categoryStmt = connection.prepareStatement(categoryQuery);
        categoryStmt.setString(1, expenseType);
        ResultSet categoryResult = categoryStmt.executeQuery();

        if (categoryResult.next()) {
            int categoryId = categoryResult.getInt("category_id");

            // Now, insert the expense into the Expense table
            String insertExpenseQuery = "INSERT INTO Expense (category_id, amount, date, notes, user_id) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement expenseStmt = connection.prepareStatement(insertExpenseQuery);
            expenseStmt.setInt(1, categoryId);
            expenseStmt.setDouble(2, amount);
            expenseStmt.setString(3, date);
            expenseStmt.setString(4, notes);
            expenseStmt.setInt(5, 1); // Assuming user_id is 1 for now, you may dynamically get the logged-in user ID.

            // Execute the insert and return true if successful
            return expenseStmt.executeUpdate() > 0;
        }
        return false;  // If no category is found, return false
    }

    // Method to get all expenses (for Delete Expense Interface)
    public ResultSet getExpenses() throws SQLException {
        String query = "SELECT expense_id, amount, date, notes FROM Expense WHERE user_id = ?";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setInt(1, 1); // Assuming user_id is 1 for now, you may dynamically get the logged-in user ID.
        return stmt.executeQuery();
    }

    // Method to delete an expense
    public boolean deleteExpense(int expenseId) throws SQLException {
        String query = "DELETE FROM Expense WHERE expense_id = ?";
        PreparedStatement stmt = connection.prepareStatement(query);
        stmt.setInt(1, expenseId);
        return stmt.executeUpdate() > 0;
    }
    
    public boolean addFunds(String incomeSource, double amount, String date, String notes) throws SQLException {
    // Prepare the query to insert into the Income table
    String query = "INSERT INTO Income (user_id, source, amount, date, notes) VALUES (?, ?, ?, ?, ?)";
    
    // Prepare the statement
    PreparedStatement stmt = connection.prepareStatement(query);
    stmt.setInt(1, 1);  // Assuming user_id is 1 for now, dynamically get the logged-in user ID if needed
    stmt.setString(2, incomeSource);  // Source of income (e.g., Salary, Gift, etc.)
    stmt.setDouble(3, amount);  // Amount of income
    stmt.setString(4, date);  // Date of income
    stmt.setString(5, notes);  // Optional notes related to the income

    // Execute the insert and return true if successful
    return stmt.executeUpdate() > 0;  // Returns true if at least one row is inserted
}
    
    public ResultSet getExpenseAnalysis(java.sql.Date startDate, java.sql.Date endDate, String category) throws SQLException {
    String query = "SELECT e.expense_id, e.amount, e.date, e.notes, c.name "
                 + "FROM Expense e JOIN Category c ON e.category_id = c.category_id "
                 + "WHERE e.date BETWEEN ? AND ? AND c.name LIKE ?";
    PreparedStatement stmt = connection.prepareStatement(query);
    stmt.setDate(1, startDate);
    stmt.setDate(2, endDate);
    stmt.setString(3, "%" + category + "%");
    return stmt.executeQuery();
}

public ResultSet getAllExpenses() throws SQLException {
    String query = "SELECT e.expense_id, c.name, e.amount, e.date, e.notes "
                 + "FROM Expense e JOIN Category c ON e.category_id = c.category_id";
    Statement stmt = connection.createStatement();
    return stmt.executeQuery(query);
}
public ResultSet getAllUsersTransactions() throws SQLException {
    String query = "SELECT e.expense_id, u.first_name, u.last_name, c.name AS category, e.amount, e.date " +
                   "FROM Expense e " +
                   "JOIN User u ON e.user_id = u.user_id " +
                   "JOIN Category c ON e.category_id = c.category_id";
    Statement stmt = connection.createStatement();
    return stmt.executeQuery(query);
}

public ResultSet getAllUsers() throws SQLException {
        String query = "SELECT user_id, first_name, last_name, email, role FROM User";
        Statement stmt = connection.createStatement();
        return stmt.executeQuery(query);
    }

public boolean deleteTransaction(String transactionId) throws SQLException {
    String deleteQuery = "DELETE FROM Expense WHERE expense_id = ?";
    try (PreparedStatement stmt = connection.prepareStatement(deleteQuery)) {
        stmt.setString(1, transactionId);
        int rowsAffected = stmt.executeUpdate();
        return rowsAffected > 0;
    }
}

 public boolean validateUser(String email, String password) throws SQLException {
        String query = "SELECT * FROM User WHERE email = ? AND password = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();  // If a matching user is found, return true
        }
    }
 
  public String getUserRole(String email) throws SQLException {
        String query = "SELECT role FROM User WHERE email = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("role");
            } else {
                return null;  // User not found
            }
        }
    }

} 
