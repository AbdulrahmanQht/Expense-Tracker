import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

public class ManageUserAccountsInterface extends JFrame {
    private DatabaseConnector dbConnector;

    public ManageUserAccountsInterface() {
        dbConnector = new DatabaseConnector();
        setTitle("Manage User Accounts");
        setSize(1000, 800);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        // Title
        JLabel titleLabel = new JLabel("Manage User Accounts");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setBounds(50, 20, 300, 30);
        add(titleLabel);

        // Users List Table
        JTable usersTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(usersTable);
        scrollPane.setBounds(50, 80, 900, 300);
        add(scrollPane);

        // Message Label
        JLabel messageLabel = new JLabel();
        messageLabel.setBounds(50, 400, 400, 25);
        add(messageLabel);

        // Edit and Delete Buttons
        JButton editButton = new JButton("Edit User");
        editButton.setBounds(50, 450, 150, 30);
        add(editButton);

        JButton deleteButton = new JButton("Delete User");
        deleteButton.setBounds(220, 450, 150, 30);
        add(deleteButton);

        // Fields for Editing User Details
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 500, 100, 25);
        add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(150, 500, 200, 25);
        add(nameField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(50, 550, 100, 25);
        add(emailLabel);

        JTextField emailField = new JTextField();
        emailField.setBounds(150, 550, 200, 25);
        add(emailField);

        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setBounds(50, 600, 100, 25);
        add(roleLabel);

        JComboBox<String> roleComboBox = new JComboBox<>();
        roleComboBox.addItem("user");
        roleComboBox.addItem("admin");
        roleComboBox.setBounds(150, 600, 200, 25);
        add(roleComboBox);

        // Populate Users Table
        try {
            dbConnector.connect();
            ResultSet rs = dbConnector.getUsers();
            Vector<Vector<Object>> data = new Vector<>();
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("user_id"));
                row.add(rs.getString("first_name") + " " + rs.getString("last_name"));
                row.add(rs.getString("email"));
                row.add(rs.getString("role"));
                data.add(row);
            }
            Vector<String> columnNames = new Vector<>(Arrays.asList("User ID", "Full Name", "Email", "Role"));
            usersTable.setModel(new DefaultTableModel(data, columnNames));
            dbConnector.disconnect();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading users: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Edit Button Action
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = usersTable.getSelectedRow();
                if (selectedRow == -1) {
                    messageLabel.setText("Please select a user to edit.");
                    return;
                }

                // Get selected user details
                int userId = (int) usersTable.getValueAt(selectedRow, 0);
                String name = (String) usersTable.getValueAt(selectedRow, 1);
                String email = (String) usersTable.getValueAt(selectedRow, 2);
                String role = (String) usersTable.getValueAt(selectedRow, 3);

                // Set selected user details in the edit fields
                nameField.setText(name);
                emailField.setText(email);
                roleComboBox.setSelectedItem(role);

                // Action to update user
                JButton updateButton = new JButton("Update User");
                updateButton.setBounds(150, 650, 150, 30);
                add(updateButton);

                updateButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            dbConnector.connect();

                            // Update user details
                            String updatedName = nameField.getText();
                            String updatedEmail = emailField.getText();
                            String updatedRole = (String) roleComboBox.getSelectedItem();

                            boolean success = dbConnector.updateUser(userId, updatedName, updatedEmail, updatedRole);

                            if (success) {
                                messageLabel.setText("User updated successfully.");
                            } else {
                                messageLabel.setText("Error updating user.");
                            }

                            dbConnector.disconnect();
                        } catch (SQLException ex) {
                            messageLabel.setText("Error: " + ex.getMessage());
                        }
                    }
                });
            }
        });

        // Delete Button Action
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = usersTable.getSelectedRow();
                if (selectedRow == -1) {
                    messageLabel.setText("Please select a user to delete.");
                    return;
                }

                int userId = (int) usersTable.getValueAt(selectedRow, 0);
                String userName = (String) usersTable.getValueAt(selectedRow, 1);

                int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete " + userName + "?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

                if (confirm == JOptionPane.YES_OPTION) {
                    try {
                        dbConnector.connect();
                        boolean success = dbConnector.deleteUser(userId);
                        if (success) {
                            messageLabel.setText("User account deleted successfully.");
                        } else {
                            messageLabel.setText("Error deleting user.");
                        }
                        dbConnector.disconnect();
                    } catch (SQLException ex) {
                        messageLabel.setText("Error: " + ex.getMessage());
                    }
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ManageUserAccountsInterface().setVisible(true));
    }
}
