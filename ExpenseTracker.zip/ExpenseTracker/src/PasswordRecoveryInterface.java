import javax.swing.*;
import java.sql.*;
import java.util.Random;

public class PasswordRecoveryInterface extends JFrame {
    private DatabaseConnector dbConnector;

    public PasswordRecoveryInterface() {
        dbConnector = new DatabaseConnector();
        setTitle("Password Recovery");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JLabel emailLabel = new JLabel("Enter Email:");
        emailLabel.setBounds(50, 50, 100, 25);
        add(emailLabel);

        JTextField emailField = new JTextField();
        emailField.setBounds(150, 50, 200, 25);
        add(emailField);

        JButton sendResetLinkButton = new JButton("Send Reset Link");
        sendResetLinkButton.setBounds(150, 100, 150, 30);
        add(sendResetLinkButton);

        JLabel verificationCodeLabel = new JLabel("Enter Verification Code:");
        verificationCodeLabel.setBounds(50, 150, 150, 25);
        add(verificationCodeLabel);

        JTextField verificationCodeField = new JTextField();
        verificationCodeField.setBounds(200, 150, 150, 25);
        add(verificationCodeField);

        JLabel passwordLabel = new JLabel("New Password:");
        passwordLabel.setBounds(50, 200, 100, 25);
        add(passwordLabel);

        JPasswordField newPasswordField = new JPasswordField();
        newPasswordField.setBounds(150, 200, 200, 25);
        add(newPasswordField);

        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setBounds(50, 250, 120, 25);
        add(confirmPasswordLabel);

        JPasswordField confirmPasswordField = new JPasswordField();
        confirmPasswordField.setBounds(200, 250, 150, 25);
        add(confirmPasswordField);

        JButton verifyButton = new JButton("Verify");
        verifyButton.setBounds(150, 300, 100, 30);
        add(verifyButton);

        JLabel errorMessageLabel = new JLabel();
        errorMessageLabel.setBounds(50, 330, 300, 25);
        errorMessageLabel.setForeground(java.awt.Color.RED);
        add(errorMessageLabel);

        // Action for Send Reset Link
        sendResetLinkButton.addActionListener(e -> {
            String email = emailField.getText();
            if (email.isEmpty()) {
                errorMessageLabel.setText("Please enter a valid email.");
                return;
            }
            try {
                dbConnector.connect();
                String token = generateVerificationToken();
                boolean emailExists = dbConnector.sendPasswordResetToken(email, token);  // Send token to the user's email

                if (emailExists) {
                    JOptionPane.showMessageDialog(this, "Reset link sent! Please check your email for the verification code.");
                } else {
                    errorMessageLabel.setText("Email not registered.");
                }
                dbConnector.disconnect();
            } catch (SQLException ex) {
                errorMessageLabel.setText("Error: " + ex.getMessage());
            }
        });

        // Action for Verify Button
        verifyButton.addActionListener(e -> {
            String enteredCode = verificationCodeField.getText();
            String newPassword = new String(newPasswordField.getPassword());
            String confirmPassword = new String(confirmPasswordField.getPassword());

            if (!newPassword.equals(confirmPassword)) {
                errorMessageLabel.setText("Passwords do not match.");
                return;
            }

            try {
                dbConnector.connect();
                boolean verified = dbConnector.verifyTokenAndResetPassword(enteredCode, newPassword);  // Verify token and reset password
                if (verified) {
                    JOptionPane.showMessageDialog(this, "Password reset successfully!");
                    dispose();  // Close the password recovery interface
                } else {
                    errorMessageLabel.setText("Invalid verification code.");
                }
                dbConnector.disconnect();
            } catch (SQLException ex) {
                errorMessageLabel.setText("Error: " + ex.getMessage());
            }
        });
    }

    // Generate a random verification token (6 digits)
    private String generateVerificationToken() {
        Random rand = new Random();
        int code = rand.nextInt(999999);
        return String.format("%06d", code);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PasswordRecoveryInterface().setVisible(true));
    }
}
