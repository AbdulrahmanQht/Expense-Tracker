import javax.swing.*;
import java.sql.*;
import java.util.regex.*;

public class LoginInterface extends JFrame {
    private DatabaseConnector dbConnector;

    public LoginInterface() {
        dbConnector = new DatabaseConnector();
        setTitle("Login");
        setSize(300, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(50, 50, 100, 25);
        add(emailLabel);

        JTextField emailField = new JTextField();
        emailField.setBounds(150, 50, 100, 25);
        add(emailField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 100, 100, 25);
        add(passwordLabel);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(150, 100, 100, 25);
        add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(100, 150, 100, 30);
        add(loginButton);

        JLabel errorLabel = new JLabel();
        errorLabel.setBounds(50, 180, 200, 25);
        errorLabel.setForeground(java.awt.Color.RED);
        add(errorLabel);

        JButton forgotPasswordButton = new JButton("Forgot Password");
        forgotPasswordButton.setBounds(50, 200, 200, 30);
        add(forgotPasswordButton);

        // Action for the Login button
        loginButton.addActionListener(e -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            // Validate email format
            if (!isValidEmail(email)) {
                errorLabel.setText("Invalid email format.");
                return;
            }

            try {
                dbConnector.connect();
                boolean isValid = dbConnector.validateUser(email, password);
                if (isValid) {
                    String role = dbConnector.getUserRole(email);
                    if ("admin".equals(role)) {
                        JOptionPane.showMessageDialog(this, "Admin Login Successful!");
                        new AdminFinancialManagementInterface(role).setVisible(true); // Redirect to Admin dashboard
                    } else if ("user".equals(role)) {
                        JOptionPane.showMessageDialog(this, "User Login Successful!");
                        new SelectionInterface().setVisible(true); // Redirect to User dashboard
                    }
                    dispose();  // Close the login screen
                } else {
                    errorLabel.setText("Invalid credentials.");
                }
                dbConnector.disconnect();
            } catch (SQLException ex) {
                errorLabel.setText("Error: " + ex.getMessage());
            }
        });

        // Action for Forgot Password button
        forgotPasswordButton.addActionListener(e -> {
            new PasswordRecoveryInterface().setVisible(true);
            dispose();  // Close login screen and open Password Recovery
        });
    }

    // Email validation regex
    private boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        return pattern.matcher(email).matches();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginInterface().setVisible(true));
    }
}
