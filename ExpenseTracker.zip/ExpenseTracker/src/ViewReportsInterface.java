import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.*;

public class ViewReportsInterface extends JFrame {
    private DatabaseConnector dbConnector;

    public ViewReportsInterface() {
        dbConnector = new DatabaseConnector();
        setTitle("View Financial Reports");
        setSize(1000, 800);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        // Date Range Filters
        JLabel startDateLabel = new JLabel("Start Date:");
        startDateLabel.setBounds(50, 50, 100, 25);
        add(startDateLabel);

        JSpinner startDateSpinner = new JSpinner(new SpinnerDateModel());
        startDateSpinner.setBounds(150, 50, 150, 25);
        JSpinner.DateEditor startDateEditor = new JSpinner.DateEditor(startDateSpinner, "yyyy-MM-dd");
        startDateSpinner.setEditor(startDateEditor);
        add(startDateSpinner);

        JLabel endDateLabel = new JLabel("End Date:");
        endDateLabel.setBounds(50, 100, 100, 25);
        add(endDateLabel);

        JSpinner endDateSpinner = new JSpinner(new SpinnerDateModel());
        endDateSpinner.setBounds(150, 100, 150, 25);
        JSpinner.DateEditor endDateEditor = new JSpinner.DateEditor(endDateSpinner, "yyyy-MM-dd");
        endDateSpinner.setEditor(endDateEditor);
        add(endDateSpinner);

        // Category Filter Dropdown
        JLabel categoryLabel = new JLabel("Category Filter:");
        categoryLabel.setBounds(50, 150, 150, 25);
        add(categoryLabel);

        JComboBox<String> categoryDropdown = new JComboBox<>();
        categoryDropdown.addItem("All Categories");
        categoryDropdown.setBounds(150, 150, 200, 25);
        add(categoryDropdown);

        // Button to generate the report
        JButton viewReportsButton = new JButton("Generate Report");
        viewReportsButton.setBounds(50, 200, 200, 30);
        add(viewReportsButton);

        // Message label for showing error or no data message
        JLabel messageLabel = new JLabel();
        messageLabel.setBounds(50, 250, 400, 25);
        add(messageLabel);

        // Table to display the transactions
        JTable reportsTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(reportsTable);
        scrollPane.setBounds(50, 300, 900, 200);
        add(scrollPane);

        // Placeholder for graphical report (e.g., pie chart, bar graph)
        JPanel chartPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Dynamically generate the graphical report inside this method
                generateGraphicalReport(g);
            }
        };
        chartPanel.setBounds(50, 550, 900, 200);
        chartPanel.setBackground(Color.WHITE);
        add(chartPanel);

        // Populate Category Dropdown
        try {
            dbConnector.connect();
            ResultSet rs = dbConnector.getCategories();
            while (rs.next()) {
                categoryDropdown.addItem(rs.getString("name"));
            }
            dbConnector.disconnect();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading categories: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Action when "Generate Report" button is clicked
        viewReportsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                java.util.Date startDate = (java.util.Date) startDateSpinner.getValue();
                java.util.Date endDate = (java.util.Date) endDateSpinner.getValue();
                String selectedCategory = (String) categoryDropdown.getSelectedItem();

                try {
                    dbConnector.connect();

                    // Convert java.util.Date to java.sql.Date explicitly
                    java.sql.Date sqlStartDate = new java.sql.Date(startDate.getTime());
                    java.sql.Date sqlEndDate = new java.sql.Date(endDate.getTime());

                    // Fetch financial data
                    ResultSet rs = dbConnector.getReportData(sqlStartDate, sqlEndDate, selectedCategory);

                    // Populate the table with results
                    Vector<Vector<Object>> data = new Vector<>();
                    ResultSetMetaData metaData = rs.getMetaData();
                    int columnCount = metaData.getColumnCount();

                    while (rs.next()) {
                        Vector<Object> row = new Vector<>(columnCount);
                        for (int i = 1; i <= columnCount; i++) {
                            row.add(rs.getObject(i));
                        }
                        data.add(row);
                    }

                    // Set the table model
                    if (!data.isEmpty()) {
                        Vector<String> columnNames = new Vector<>(columnCount);
                        for (int i = 1; i <= columnCount; i++) {
                            columnNames.add(metaData.getColumnName(i));
                        }
                        reportsTable.setModel(new DefaultTableModel(data, columnNames));
                        messageLabel.setText("");  // Clear any previous error message
                    } else {
                        messageLabel.setText("No data available for the selected filters.");
                        reportsTable.setModel(new DefaultTableModel()); // Clear table
                    }

                    // Generate Graphical Report (e.g., Bar Graph, Pie Chart)
                    chartPanel.repaint(); // Repaint the chart panel to display the updated chart

                    dbConnector.disconnect();
                } catch (SQLException ex) {
                    messageLabel.setText("Error fetching data: " + ex.getMessage());
                }
            }
        });

        // Export Button for CSV
        JButton exportButton = new JButton("Export as CSV");
        exportButton.setBounds(650, 100, 150, 30);
        add(exportButton);

        exportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exportToCSV(reportsTable);  // Export the table data to CSV
            }
        });
    }

    // Method to export JTable data to CSV
    private void exportToCSV(JTable table) {
        try {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Save CSV");
            int result = fileChooser.showSaveDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                if (!file.getName().endsWith(".csv")) {
                    file = new File(file.getAbsolutePath() + ".csv");
                }

                try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                    DefaultTableModel model = (DefaultTableModel) table.getModel();
                    // Write column names
                    for (int i = 0; i < model.getColumnCount(); i++) {
                        writer.write(model.getColumnName(i));
                        if (i < model.getColumnCount() - 1) writer.write(",");
                    }
                    writer.newLine();

                    // Write row data
                    for (int i = 0; i < model.getRowCount(); i++) {
                        for (int j = 0; j < model.getColumnCount(); j++) {
                            writer.write(model.getValueAt(i, j).toString());
                            if (j < model.getColumnCount() - 1) writer.write(",");
                        }
                        writer.newLine();
                    }
                    JOptionPane.showMessageDialog(this, "CSV file saved successfully.", "Export Successful", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error exporting to CSV: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to dynamically generate graphical report (Pie and Bar charts)
    private void generateGraphicalReport(Graphics g) {
        // Assume that we already have some data, for example purposes
        Map<String, Double> categoryData = new HashMap<>();
        categoryData.put("Food", 1000.0);
        categoryData.put("Entertainment", 500.0);
        categoryData.put("Transportation", 300.0);
        
        // Draw a simple Bar Chart
        drawBarChart(g, categoryData);

        // Draw a Pie Chart
        drawPieChart(g, categoryData);
    }

    // Draw Pie Chart
    private void drawPieChart(Graphics g, Map<String, Double> categoryData) {
        int total = categoryData.values().stream().mapToInt(Double::intValue).sum();
        int startAngle = 0;
        int arcAngle;

        int pieX = 600, pieY = 50, pieWidth = 150, pieHeight = 150;
        for (Map.Entry<String, Double> entry : categoryData.entrySet()) {
            arcAngle = (int) (entry.getValue() / total * 360);
            g.setColor(new Color((int)(Math.random() * 0x1000000)));  // Random color
            g.fillArc(pieX, pieY, pieWidth, pieHeight, startAngle, arcAngle);
            startAngle += arcAngle;
        }
    }

    // Draw Bar Chart
    private void drawBarChart(Graphics g, Map<String, Double> categoryData) {
        int barWidth = 50;
        int space = 20;
        int baseY = 200;
        int maxHeight = 200;
        int x = 50;

        double maxValue = Collections.max(categoryData.values());

        for (Map.Entry<String, Double> entry : categoryData.entrySet()) {
            int barHeight = (int) (entry.getValue() / maxValue * maxHeight);
            g.setColor(Color.BLUE);
            g.fillRect(x, baseY - barHeight, barWidth, barHeight);
            g.setColor(Color.BLACK);
            g.drawString(entry.getKey(), x, baseY + 20);
            x += barWidth + space;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ViewReportsInterface().setVisible(true));
    }
}
