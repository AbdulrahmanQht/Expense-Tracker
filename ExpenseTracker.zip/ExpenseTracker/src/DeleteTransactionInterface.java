import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Vector;
import javax.swing.table.*;

public class DeleteTransactionInterface extends JFrame {
    private DatabaseConnector dbConnector;

    public DeleteTransactionInterface() {
        dbConnector = new DatabaseConnector();
        setTitle("Delete Transaction");
        setSize(800, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        // Label for showing user transactions
        JLabel manageLabel = new JLabel("Select User Transaction to Delete:");
        manageLabel.setBounds(50, 50, 250, 25);
        add(manageLabel);

        // Create a JTable to display users and their transactions
        JTable transactionTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(transactionTable);
        scrollPane.setBounds(50, 100, 700, 300);
        add(scrollPane);

        // Button to delete the selected transaction
        JButton deleteButton = new JButton("Delete Transaction");
        deleteButton.setBounds(50, 420, 200, 30);
        add(deleteButton);

        // Message label for showing success/error message
        JLabel messageLabel = new JLabel();
        messageLabel.setBounds(50, 460, 300, 25);
        add(messageLabel);

        // Fetch and display all users with their transactions
        displayUserTransactions(transactionTable);

        // Action when "Delete Transaction" button is clicked
        deleteButton.addActionListener(e -> {
            int selectedRow = transactionTable.getSelectedRow();
            if (selectedRow == -1) {
                messageLabel.setText("Please select a transaction to delete.");
                return;
            }

            // Get the transaction ID of the selected row
            String transactionId = transactionTable.getValueAt(selectedRow, 0).toString();

            // Show confirmation dialog
            int confirmation = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to delete this transaction?",
                    "Confirm Deletion",
                    JOptionPane.YES_NO_OPTION);

            if (confirmation == JOptionPane.YES_OPTION) {
                try {
                    dbConnector.connect();
                    boolean success = dbConnector.deleteTransaction(transactionId);
                    dbConnector.disconnect();

                    // Show success or error message
                    if (success) {
                        messageLabel.setText("Transaction deleted successfully.");
                        displayUserTransactions(transactionTable); // Refresh the table
                    } else {
                        messageLabel.setText("Error: Deletion failed.");
                    }
                } catch (SQLException ex) {
                    messageLabel.setText("Error: " + ex.getMessage());
                }
            }
        });
    }

    // Helper method to display all users and their transactions in a JTable
    private void displayUserTransactions(JTable transactionTable) {
        try {
            dbConnector.connect();
            ResultSet rs = dbConnector.getAllUsersTransactions();
            transactionTable.setModel(buildTableModel(rs));
            dbConnector.disconnect();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching transactions: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Helper method to convert ResultSet to TableModel for JTable
    private static TableModel buildTableModel(ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
        int columnCount = metaData.getColumnCount();
        Vector<String> columnNames = new Vector<>(columnCount);
        for (int i = 1; i <= columnCount; i++) {
            columnNames.add(metaData.getColumnName(i));
        }

        Vector<Vector<Object>> data = new Vector<>();
        while (rs.next()) {
            Vector<Object> row = new Vector<>(columnCount);
            for (int i = 1; i <= columnCount; i++) {
                row.add(rs.getObject(i));
            }
            data.add(row);
        }

        return new DefaultTableModel(data, columnNames);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DeleteTransactionInterface().setVisible(true));
    }
}
